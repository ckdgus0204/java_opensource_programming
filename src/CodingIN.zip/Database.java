package CodingIN;

import java.sql.*;
public class Database 
{
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    Database()
    {
        try{
             
            //MAKE SURE YOU KEEP THE mysql_connector.jar file in java/lib folder
            //ALSO SET THE CLASSPATH
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://54.180.119.81:3306/myimages?serverTimezone=UTC&useSSL=false","root","!ntbt0927");
            
             
           }
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
        //ip:username,password
        //return boolean
    public Boolean checkLogin(String ID,String Pwd)
    {
        try {
        	pst=con.prepareStatement("select * from client_table where ID=? and Pwd=?");            
            pst.setString(1, ID); //this replaces the 1st  "?" in the query for username
            pst.setString(2, Pwd);    //this replaces the 2st  "?" in the query for password
            //executes the prepared statement
            rs=pst.executeQuery();
            if(rs.next())
            {
                //TRUE iff the query founds any corresponding data
                return true;
            }
            else
            {
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("error while validating"+e);
            return false;
        }
    }
    public void regist(String Id, String Pwd, String Name, String Birth, String Email) {
		
		try {
			
			String query = "insert into client_table(Id, Pwd, Name, Birth, Email) values (?,?,?,?,?)";//���� �ɹ�2
			pst = con.prepareStatement(query);
			pst.setString(1, Id);
			pst.setString(2, Pwd);
			pst.setString(3, Name);
			pst.setString(4, Birth);
			pst.setString(5, Email);
			
			
			pst.executeUpdate();
					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pst != null) pst.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
}